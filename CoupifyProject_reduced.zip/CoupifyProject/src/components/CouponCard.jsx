import React from 'react';
import { motion } from 'framer-motion';
import { Copy, Check, Clock, ExternalLink } from 'lucide-react';
import { format, parseISO } from 'date-fns';
import confetti from 'canvas-confetti';
import { toast } from 'react-hot-toast';
import { useCoupons } from '../context/CouponContext';
import './CouponCard.css';

const CouponCard = ({ coupon }) => {
  const { markAsUsed } = useCoupons();
  const [copied, setCopied] = React.useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(coupon.code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const isExpired = coupon.status === 'expired';
  const isUsed = coupon.status === 'used';

  const getStatusColor = () => {
    if (isExpired) return 'var(--accent-danger)';
    if (isUsed) return 'var(--text-muted)';
    return 'var(--accent-success)';
  };

  const handleMarkUsed = () => {
    // Fire confetti
    const end = Date.now() + 1.5 * 1000;
    const colors = ['#8b5cf6', '#d946ef', '#06b6d4', '#f59e0b'];

    (function frame() {
      confetti({
        particleCount: 3,
        angle: 60,
        spread: 55,
        origin: { x: 0 },
        colors: colors
      });
      confetti({
        particleCount: 3,
        angle: 120,
        spread: 55,
        origin: { x: 1 },
        colors: colors
      });

      if (Date.now() < end) {
        requestAnimationFrame(frame);
      }
    }());

    toast.success('Yayy! Coupon used successfully 🎉💥', {
      duration: 3000,
      position: 'top-center',
      style: {
        background: 'linear-gradient(to right, #8b5cf6, #d946ef)',
        color: '#fff',
        fontWeight: 'bold',
        borderRadius: '16px',
        padding: '16px',
        boxShadow: '0 4px 14px rgba(217, 70, 239, 0.4)'
      },
      iconTheme: {
        primary: '#fff',
        secondary: '#d946ef',
      },
    });

    markAsUsed(coupon.id);
  };

  return (
    <motion.div 
      className={`coupon-card glass-panel ${coupon.status} ${coupon.isNew ? 'is-new' : ''}`}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={!isExpired && !isUsed ? { y: -5, scale: 1.02 } : {}}
      transition={{ duration: 0.2 }}
    >
      {coupon.isNew && (
        <div className="new-badge absolute top-0 right-0" style={{ position: 'absolute', top: '12px', right: '12px', background: 'var(--accent)', color: '#000', padding: '2px 8px', borderRadius: '12px', fontSize: '10px', fontWeight: 'bold', zIndex: 10 }}>
          NEW
        </div>
      )}
      <div className="coupon-header">
        <span className="category-tag">{coupon.category}</span>
        <div className="status-indicator" style={{ backgroundColor: getStatusColor() }}>
          {isExpired ? 'Expired' : isUsed ? 'Used' : 'Active'}
        </div>
      </div>

      <div className="coupon-body">
        <h3 className="coupon-title">{coupon.title}</h3>
        <p className="coupon-platform">{coupon.platform}</p>
        
        <div className="expiry-info">
          <Clock size={16} />
          <span>Valid till {format(parseISO(coupon.expiryDate), 'MMM dd, yyyy')}</span>
        </div>
      </div>

      <div className="coupon-footer">
        <div className="code-container">
          <span className="code-text">{coupon.code || 'NO CODE'}</span>
          {coupon.code && coupon.code !== 'NONE' && !isExpired && (
            <button className="copy-btn" onClick={handleCopy} title="Copy code">
              {copied ? <Check size={16} color="var(--accent-success)" /> : <Copy size={16} />}
            </button>
          )}
        </div>

        {!isExpired && !isUsed && (
          <button 
            className="mark-used-btn btn-primary"
            onClick={handleMarkUsed}
            style={{ fontWeight: 'bold' }}
          >
            Mark Used
          </button>
        )}
      </div>
    </motion.div>
  );
};

export default CouponCard;
