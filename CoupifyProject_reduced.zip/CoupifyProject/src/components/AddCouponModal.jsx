import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Gift } from 'lucide-react';
import { useCoupons } from '../context/CouponContext';
import './AddCouponModal.css';

const CATEGORIES = ['Food', 'Shopping', 'Travel', 'Cashback', 'Entertainment', 'Other'];
const TYPES = ['Discount', 'Cashback', 'Voucher', 'Freebie'];

const AddCouponModal = ({ onClose }) => {
  const { addCoupon } = useCoupons();
  
  const [formData, setFormData] = useState({
    title: '',
    platform: '',
    category: 'Food',
    expiryDate: '',
    code: '',
    type: 'Discount'
  });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    addCoupon(formData);
    onClose();
  };

  return (
    <div className="modal-overlay">
      <motion.div 
        className="modal-content glass-panel"
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.9 }}
      >
        <button className="close-btn btn-icon" onClick={onClose}>
          <X size={24} />
        </button>

        <div className="modal-header">
          <div className="icon-wrapper">
            <Gift size={24} />
          </div>
          <h2>Add New Reward</h2>
          <p>Scratched a new card? Add it here before you forget!</p>
        </div>

        <form onSubmit={handleSubmit} className="add-coupon-form">
          <div className="form-group">
            <label>Reward Title *</label>
            <input 
              type="text" 
              name="title" 
              required 
              placeholder="e.g. 50% Off up to ₹100"
              value={formData.title}
              onChange={handleChange}
            />
          </div>

          <div className="form-row">
            <div className="form-group">
              <label>Platform/App *</label>
              <input 
                type="text" 
                name="platform" 
                required 
                placeholder="e.g. Swiggy, Amazon"
                value={formData.platform}
                onChange={handleChange}
              />
            </div>

            <div className="form-group">
              <label>Category *</label>
              <select name="category" value={formData.category} onChange={handleChange}>
                {CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>
          </div>

          <div className="form-row">
            <div className="form-group">
              <label>Expiry Date *</label>
              <input 
                type="date" 
                name="expiryDate" 
                required 
                value={formData.expiryDate}
                onChange={handleChange}
              />
            </div>
            
            <div className="form-group">
              <label>Reward Type *</label>
              <select name="type" value={formData.type} onChange={handleChange}>
                {TYPES.map(t => <option key={t} value={t}>{t}</option>)}
              </select>
            </div>
          </div>

          <div className="form-group">
            <label>Coupon Code (Optional)</label>
            <input 
              type="text" 
              name="code" 
              placeholder="e.g. WELCOME50"
              value={formData.code}
              onChange={handleChange}
            />
          </div>

          <motion.button 
            type="submit" 
            className="btn-primary submit-btn"
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
          >
            Save Reward
          </motion.button>
        </form>
      </motion.div>
    </div>
  );
};

export default AddCouponModal;
