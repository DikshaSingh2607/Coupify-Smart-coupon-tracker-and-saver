import React from 'react';
import { motion } from 'framer-motion';
import { X, Sparkles } from 'lucide-react';
import { useCoupons } from '../context/CouponContext';
import CouponCard from './CouponCard';
import './AddCouponModal.css';

const SmartSuggestionModal = ({ platform, onClose }) => {
  const { activeCoupons } = useCoupons();

  // Smart Suggestion Logic: Get active coupons for platform, sort by expiry date (soonest first)
  const suggestions = activeCoupons
    .filter(c => c.platform === platform)
    .sort((a, b) => new Date(a.expiryDate) - new Date(b.expiryDate));

  const bestOption = suggestions.length > 0 ? suggestions[0] : null;

  return (
    <div className="modal-overlay">
      <motion.div 
        className="modal-content glass-panel"
        initial={{ opacity: 0, y: 50 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: 50 }}
        style={{ maxWidth: '450px' }}
      >
        <button className="close-btn btn-icon" onClick={onClose}>
          <X size={24} />
        </button>

        <div className="modal-header">
          <div className="icon-wrapper" style={{ background: 'var(--accent-warning)', color: '#000' }}>
            <Sparkles size={24} />
          </div>
          <h2>Smart Suggestion</h2>
          <p>Shopping on {platform}? Here is the best reward to maximize your savings.</p>
        </div>

        {bestOption ? (
          <div style={{ marginTop: '24px' }}>
            <CouponCard coupon={bestOption} />
            {suggestions.length > 1 && (
              <p style={{ textAlign: 'center', marginTop: '16px', fontSize: '14px', color: 'var(--text-secondary)' }}>
                You have {suggestions.length - 1} other valid reward(s) for {platform}.
              </p>
            )}
          </div>
        ) : (
          <p style={{ textAlign: 'center', color: 'var(--text-secondary)' }}>
            No active rewards found for {platform}.
          </p>
        )}

      </motion.div>
    </div>
  );
};

export default SmartSuggestionModal;
