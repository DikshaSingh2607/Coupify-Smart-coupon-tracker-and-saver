import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Gift, Lock, User, Phone, MapPin } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import './AuthView.css';

const AuthView = () => {
  const { login, register } = useAuth();
  const [isLogin, setIsLogin] = useState(true);
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [phone, setPhone] = useState('');
  const [city, setCity] = useState('');
  const [errorText, setErrorText] = useState('');
  const [emailError, setEmailError] = useState('');
  const [passwordError, setPasswordError] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    setErrorText('');
    setEmailError('');
    setPasswordError('');

    if (isLogin) {
      if (email && password) {
        const res = login(email, password);
        if (!res.success) {
          setErrorText(res.error);
        }
      }
    } else {
      let isValid = true;
      if (!email.endsWith("@gmail.com")) {
        setEmailError("Only Gmail addresses allowed 📩");
        isValid = false;
      }
      
      const passwordRegex = /^(?=.*[A-Z])(?=.*[^A-Za-z0-9]).{8,}$/;
      if (!passwordRegex.test(password)) {
        setPasswordError("Password must be 8+ characters, include 1 uppercase & 1 special character ⚠️");
        isValid = false;
      }

      if (!isValid) return;

      if (email && password && username && phone) {
        const res = register(username, email, password, phone, city);
        if (res.success) {
          import('react-hot-toast').then(({ toast }) => toast.success('Account created! Please log in.', {
            style: { borderRadius: '10px', background: '#333', color: '#fff' },
          }));
          setIsLogin(true);
          setPassword('');
        } else {
          setErrorText(res.error);
        }
      }
    }
  };

  return (
    <div className="auth-container">
      <div className="auth-background">
        <div className="blob blob-1"></div>
        <div className="blob blob-2"></div>
      </div>

      <motion.div 
        className="auth-card glass-panel"
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.4 }}
      >
        <div className="auth-header">
          <div className="logo-icon">
            <Gift size={32} color="var(--text-primary)" />
          </div>
          <h1>Coupify</h1>
          <p>Your smart coupon tracker & saver</p>
        </div>

        <form onSubmit={handleSubmit} className="auth-form">
          {!isLogin && (
            <div className="input-group">
              <User className="input-icon" size={20} />
              <input 
                type="text" 
                placeholder="Username" 
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                required
              />
            </div>
          )}

          <div className="input-group">
            <User className="input-icon" size={20} />
            <input 
              type="email" 
              placeholder="Email address" 
              value={email}
              onChange={(e) => { setEmail(e.target.value); setEmailError(''); }}
              required
            />
          </div>
          
          <AnimatePresence>
            {emailError && !isLogin && (
              <motion.div 
                initial={{ opacity: 0, height: 0 }} 
                animate={{ opacity: 1, height: 'auto' }} 
                exit={{ opacity: 0, height: 0 }}
                style={{ color: 'var(--accent-danger)', fontSize: '0.8rem', marginTop: '-0.5rem', marginBottom: '1rem', textAlign: 'left' }}
              >
                {emailError}
              </motion.div>
            )}
          </AnimatePresence>
          
          <div className="input-group">
            <Lock className="input-icon" size={20} />
            <input 
              type="password" 
              placeholder="Password" 
              value={password}
              onChange={(e) => { setPassword(e.target.value); setPasswordError(''); }}
              required
            />
          </div>

          <AnimatePresence>
            {passwordError && !isLogin && (
              <motion.div 
                initial={{ opacity: 0, height: 0 }} 
                animate={{ opacity: 1, height: 'auto' }} 
                exit={{ opacity: 0, height: 0 }}
                style={{ color: 'var(--accent-danger)', fontSize: '0.8rem', marginTop: '-0.5rem', marginBottom: '1rem', textAlign: 'left' }}
              >
                {passwordError}
              </motion.div>
            )}
          </AnimatePresence>

          {!isLogin && (
            <>
              <div className="input-group">
                <Phone className="input-icon" size={20} />
                <input 
                  type="tel" 
                  placeholder="Phone Number" 
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  required
                />
              </div>
              <div className="input-group">
                <MapPin className="input-icon" size={20} />
                <input 
                  type="text" 
                  placeholder="City or Location (Optional)" 
                  value={city}
                  onChange={(e) => setCity(e.target.value)}
                />
              </div>
            </>
          )}

          <AnimatePresence>
            {errorText && (
              <motion.div 
                initial={{ opacity: 0, height: 0 }} 
                animate={{ opacity: 1, height: 'auto' }} 
                exit={{ opacity: 0, height: 0 }}
                className="error-message"
                style={{ color: 'var(--accent-danger)', fontSize: '0.85rem', marginTop: '-0.5rem', marginBottom: '0.5rem' }}
              >
                {errorText}
              </motion.div>
            )}
          </AnimatePresence>

          <motion.button 
            type="submit" 
            className="btn-primary w-full"
            whileHover={{ scale: 1.02, boxShadow: '0 0 15px var(--accent)' }}
            whileTap={{ scale: 0.98 }}
            style={{ fontWeight: '600' }}
          >
            {isLogin ? 'Sign In' : 'Create Account'}
          </motion.button>
        </form>

        <div className="auth-footer">
          <button 
            type="button" 
            className="text-btn"
            onClick={() => setIsLogin(!isLogin)}
          >
            {isLogin ? "Don't have an account? Sign up" : "Already have an account? Sign in"}
          </button>
        </div>
      </motion.div>
    </div>
  );
};

export default AuthView;
