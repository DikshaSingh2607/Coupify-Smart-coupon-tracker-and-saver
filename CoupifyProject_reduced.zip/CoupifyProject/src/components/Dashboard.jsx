import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Plus, Bell, LogOut, Ticket, Settings, Grid, Tag } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useCoupons } from '../context/CouponContext';
import CouponCard from './CouponCard';
import AddCouponModal from './AddCouponModal';
import SmartSuggestionModal from './SmartSuggestionModal';
import './Dashboard.css';

const Dashboard = () => {
  const { user, logout } = useAuth();
  const { 
    activeCoupons, 
    expiringSoon, 
    expiredCoupons, 
    usedCoupons 
  } = useCoupons();

  const [activeTab, setActiveTab] = useState('active');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [selectedPlatform, setSelectedPlatform] = useState(null);

  const getFilteredCoupons = () => {
    switch (activeTab) {
      case 'expiring': return expiringSoon;
      case 'expired': return expiredCoupons;
      case 'used': return usedCoupons;
      default: return activeCoupons;
    }
  };

  const platforms = [...new Set(activeCoupons.map(c => c.platform))];

  return (
    <div className="dashboard-container">
      {/* Sidebar */}
      <aside className="sidebar glass-panel border-r" style={{ borderRadius: 0, borderRight: '1px solid var(--border-light)' }}>
        <div className="logo" style={{ display: 'flex', alignItems: 'center', gap: '8px', padding: '24px', fontSize: '1.8rem', fontWeight: 800 }}>
          🎟️ <span className="brand gradient-text">Coupify</span>
        </div>
        
        <nav className="sidebar-nav">
          <button className={`nav-item ${activeTab === 'active' ? 'active' : ''}`} onClick={() => setActiveTab('active')}>
            <Grid size={20} /> Active Rewards
          </button>
          <button className={`nav-item ${activeTab === 'expiring' ? 'active' : ''}`} onClick={() => setActiveTab('expiring')}>
            <Bell size={20} /> Expiring Soon
            {expiringSoon.length > 0 && <span className="badge">{expiringSoon.length}</span>}
          </button>
          <button className={`nav-item ${activeTab === 'used' ? 'active' : ''}`} onClick={() => setActiveTab('used')}>
            <Tag size={20} /> Used
          </button>
          <button className={`nav-item ${activeTab === 'expired' ? 'active' : ''}`} onClick={() => setActiveTab('expired')}>
            <Settings size={20} /> Expired
          </button>
        </nav>

        <div className="sidebar-footer">
          <div className="user-profile">
            <img src={user.avatar} alt="Avatar" className="avatar" />
            <div className="user-info">
              <span className="user-name">{user.name}</span>
              {user.phone && <span className="user-phone" style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>{user.phone}</span>}
              {user.city && <span className="user-city" style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>{user.city}</span>}
            </div>
          </div>
          <button onClick={logout} className="btn-icon" title="Logout">
            <LogOut size={20} />
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="main-content">
        <header className="topbar">
          <div>
            <h1 className="page-title">Welcome back, {user.name}! 👋</h1>
            <p className="page-subtitle">
              {activeCoupons.length > 0 
                ? `You have ${activeCoupons.length} active rewards waiting to be used.`
                : 'Ready to stack some savings?'}
            </p>
          </div>
          <div style={{ display: 'flex', gap: '12px' }}>
            <motion.button 
              className="btn-primary"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => setIsAddModalOpen(true)}
            >
              <Plus size={20} /> Add Reward
            </motion.button>
          </div>
        </header>

        {/* Platform Filters for Smart Suggestions */}
        {platforms.length > 0 && (
          <div className="platform-filters">
            <h3>Quick Actions</h3>
            <div className="chips">
              {platforms.map(p => (
                <button 
                  key={p} 
                  className="chip btn-secondary"
                  onClick={() => setSelectedPlatform(p)}
                >
                  Shopping on {p}?
                </button>
              ))}
            </div>
          </div>
        )}

        <div className="coupons-grid">
          {getFilteredCoupons().length === 0 ? (
            <div className="empty-state">
              <h2>Low on coupons? That’s kinda sus 👀💸</h2>
              <p>Let’s fix that — drop your first deal and start winning 🛍️✨</p>
              <button className="add-btn" onClick={() => setIsAddModalOpen(true)}>✨ Add Your First Coupon</button>
            </div>
          ) : (
            getFilteredCoupons().map(coupon => (
              <CouponCard key={coupon.id} coupon={coupon} />
            ))
          )}
        </div>
      </main>

      {isAddModalOpen && (
        <AddCouponModal onClose={() => setIsAddModalOpen(false)} />
      )}
      
      
      {selectedPlatform && (
        <SmartSuggestionModal 
          platform={selectedPlatform} 
          onClose={() => setSelectedPlatform(null)} 
        />
      )}
    </div>
  );
};

export default Dashboard;
