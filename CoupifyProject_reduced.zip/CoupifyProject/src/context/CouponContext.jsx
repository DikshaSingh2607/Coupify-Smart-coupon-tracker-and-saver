import React, { createContext, useContext, useState, useEffect } from 'react';
import { isAfter, isBefore, startOfDay, addDays, parseISO } from 'date-fns';

const CouponContext = createContext();

export const useCoupons = () => useContext(CouponContext);

export const CouponProvider = ({ children }) => {
  const [coupons, setCoupons] = useState([]);
  const [loading, setLoading] = useState(true);

  // Initial load
  useEffect(() => {
    const rawCoupons = localStorage.getItem('coupify_coupons');
    let parsed = [];
    if (rawCoupons) {
      parsed = JSON.parse(rawCoupons);
    }

    // Auto update expired status
    const updatedStatus = parsed.map(coupon => {
      if (coupon.status !== 'used') {
        const today = startOfDay(new Date());
        const expiry = startOfDay(parseISO(coupon.expiryDate));
        if (isBefore(expiry, today)) {
          return { ...coupon, status: 'expired' };
        }
      }
      return coupon;
    });

    if (JSON.stringify(parsed) !== JSON.stringify(updatedStatus)) {
      localStorage.setItem('coupify_coupons', JSON.stringify(updatedStatus));
    }

    setCoupons(updatedStatus);
    setLoading(false);
  }, []);

  const saveCoupons = (newCoupons) => {
    setCoupons(newCoupons);
    localStorage.setItem('coupify_coupons', JSON.stringify(newCoupons));
  };

  const addCoupon = (couponData) => {
    const newCoupon = {
      ...couponData,
      id: crypto.randomUUID(),
      status: 'active',
      createdAt: new Date().toISOString()
    };
    saveCoupons([newCoupon, ...coupons]);
  };

  const editCoupon = (id, updatedData) => {
    saveCoupons(coupons.map(c => c.id === id ? { ...c, ...updatedData } : c));
  };

  const deleteCoupon = (id) => {
    saveCoupons(coupons.filter(c => c.id !== id));
  };

  const markAsUsed = (id) => {
    saveCoupons(coupons.map(c => c.id === id ? { ...c, status: 'used' } : c));
  };

  // Computed values
  const activeCoupons = coupons.filter(c => c.status === 'active');
  const usedCoupons = coupons.filter(c => c.status === 'used');
  const expiredCoupons = coupons.filter(c => c.status === 'expired');
  
  const expiringSoon = activeCoupons.filter(c => {
    const today = startOfDay(new Date());
    const expiry = startOfDay(parseISO(c.expiryDate));
    const diffTime = Math.abs(expiry - today);
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)); 
    return diffDays <= 3; // within 3 days
  });

  return (
    <CouponContext.Provider value={{ 
      coupons, 
      loading,
      addCoupon,
      editCoupon, 
      deleteCoupon,
      markAsUsed,
      activeCoupons,
      usedCoupons,
      expiredCoupons,
      expiringSoon
    }}>
      {children}
    </CouponContext.Provider>
  );
};
