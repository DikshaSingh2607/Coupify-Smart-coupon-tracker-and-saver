import React, { createContext, useContext, useState, useEffect } from 'react';

const AuthContext = createContext();

export const useAuth = () => useContext(AuthContext);

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Check local storage for mock session
    const storedUser = localStorage.getItem('coupify_user');
    if (storedUser) {
      setUser(JSON.parse(storedUser));
    }
    setLoading(false);
  }, []);

  const login = (email, password) => {
    // Check if user exists in our mock database
    const usersStr = localStorage.getItem('coupify_registered_users');
    let users = [];
    if (usersStr) {
      users = JSON.parse(usersStr);
    }
    
    // Find matching user (simulate backend auth)
    const existingUser = users.find(u => u.email === email && u.password === password);
    
    if (existingUser) {
      // Remove password from session
      const { password, ...sessionUser } = existingUser;
      setUser(sessionUser);
      localStorage.setItem('coupify_user', JSON.stringify(sessionUser));
      return { success: true };
    } else {
      return { success: false, error: 'Invalid email or password' };
    }
  };

  const register = (username, email, password, phone = '', city = '') => {
    const usersStr = localStorage.getItem('coupify_registered_users');
    let users = [];
    if (usersStr) {
      users = JSON.parse(usersStr);
    }

    if (users.find(u => u.email === email)) {
      return { success: false, error: 'Email already exists' };
    }

    const newUser = {
      id: crypto.randomUUID(),
      name: username || email.split('@')[0],
      email,
      password, // in a real app this would be hashed
      phone,
      city,
      avatar: `https://ui-avatars.com/api/?name=${username || email}&background=8b5cf6&color=fff`
    };

    users.push(newUser);
    localStorage.setItem('coupify_registered_users', JSON.stringify(users));
    
    // FORCE CLEAN STATE ON SIGNUP
    localStorage.removeItem('coupify_coupons');
    
    return { success: true };
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('coupify_user');
  };

  return (
    <AuthContext.Provider value={{ user, loading, login, register, logout }}>
      {children}
    </AuthContext.Provider>
  );
};
