import { AuthProvider, useAuth } from './context/AuthContext';
import { CouponProvider } from './context/CouponContext';
import AuthView from './components/AuthView';
import Dashboard from './components/Dashboard';
import { Toaster } from 'react-hot-toast';

function AppContent() {
  const { user, loading } = useAuth();

  if (loading) return null;

  if (!user) {
    return (
      <>
        <AuthView />
        <Toaster position="top-center" />
      </>
    );
  }

  return (
    <CouponProvider>
      <Dashboard />
      <Toaster position="top-center" />
    </CouponProvider>
  );
}

function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}

export default App;
